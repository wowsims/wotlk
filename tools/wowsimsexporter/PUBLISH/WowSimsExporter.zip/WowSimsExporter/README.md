# wowsimsexporter
An exporter addon for World Of Warcraft: TBC Classic Sim at  https://wowsims.github.io/tbc

There is a channel on the wowsims tbc discord

Invite is located here https://discord.gg/N9ZgAMXQ3p


**THIS IS IN TESTING, THE ADDON MAY NOT WORK**
If this is the case, don't open a ticket on the wowsims github, open it here <https://github.com/generalwrex/wowsimsexporter/issues>

**Getting the addon**

If anyone would like to test it, you can just download the repository and put the `wowsimsexporter-main` folder in your addons directory. Eventually it will be an addon on wowup/curseforge.

Here is a direct link to the latest that ive uploaded
https://github.com/generalwrex/wowsimsexporter/archive/refs/heads/main.zip

**To use the addon**

    /wse - will open up the options window - *wip* changes do nothing atm
    /wse open - will open the exporter window.
    /wse export will open the exporter window, generate the data, and have the data ready and highlighted for you to CTRL+C

If you change your gear, and enchants or some gems, you can either rerun `/wse export` if you closed the window and the data will be updated. or just click the `Generate Data` button.

**To find the import button**

As this is in a testing phase, the import button his hidden from the website to avoid issues with users not knowing where the addon is!

To find the import button you can see it by going to any of the sims and adding `?debug` to the URL. If there is a # in the URL the `?debug` has to come first.

This will add a import button to the top right of the page to the right of the report a feature button.

example: https://wowsims.github.io/tbc/enhancement_shaman/?debug#


# INFO
The aim for this project is to have an addon to export your characters gear, enchants, and gems to any number of simulation websites that are floating around, currently the only support is for the team at wowsims.github.io.


# CONTRIBUTING
If you would like to contribute, please feel free!

It was created using World of Warcraft Addon Creator 2015, its a very good IDE based on visual studio, its not required to be used, but if new files are added, please adjust the project file to match if not using WoWAC2015.



